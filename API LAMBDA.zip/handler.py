import sys
import logging
import config
import pymysql
import json
# rds settings
rds_host  = "asset-manager-db.c9zxukrtlwzh.us-east-2.rds.amazonaws.com"
name = config.db_username
password = config.db_password
db_name = config.db_name

print(rds_host)
# logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# connect using creds from rds_config.py
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, port=3306)
except Exception as e:
    print(e)
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")

# array to store values to be returned
records = []

# executes upon API event
def lambda_handler(event, context):
    data = {
        json.dumps({
        'user': event['user'],
        'pass': event['pass'],
        'fullname': event['fullname'],
        'department': event['department'],
        'roleID': event['role_id']
        })
    }

    with conn.cursor() as cur:
        sql = "INSERT INTO `tbl_users` (`user_password`, `fullname`, `department`, `role_id`) VALUES (%s, %s, %s, %s, %s)"
        cur.execute(sql, (data['key'], data['pass'], data['fullname'], data['department'], data['roleID']))
        conn.commit()

    return ({
        'statusCode': 200,
        'body': data,
        })